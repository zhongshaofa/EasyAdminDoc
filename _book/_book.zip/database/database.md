# 命名规范
好的命名规范会让你开发起来更加心情开朗，下面是一些建议：

#####表名
* 命名规则：前缀+模块+标识
* 例如：
    * ea_system_admin
    * ea_system_config
    * ea_blog_user
    * ea_blog_config
    
#####字段
`create_time`、`update_time`、`delete_time`三个字段以int类型保存时间信息